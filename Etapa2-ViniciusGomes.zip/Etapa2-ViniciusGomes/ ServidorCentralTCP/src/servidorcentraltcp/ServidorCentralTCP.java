package servidorcentraltcp;

import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.ServerSocket;
import java.net.Socket;

/**
 *
 * @author vinic
 */
public class ServidorCentralTCP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int porta = 8000;
           try {
            ServerSocket servidor = new ServerSocket(porta);
            System.out.println("Servidor ouvindo na porta " + porta);

            while (true) {
                Socket cliente = servidor.accept();
                System.out.println("Cliente conectado: " + cliente.getInetAddress().getHostAddress());

                // Streams para receber e enviar dados
                ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());
                ObjectOutputStream saida = new ObjectOutputStream(cliente.getOutputStream());

                String mensagemCliente;

                do {
                    mensagemCliente = (String) entrada.readObject();
                    System.out.println("Cliente enviou: " + mensagemCliente);

                    if (!mensagemCliente.equalsIgnoreCase("sair")) {
                        // Processa a mensagem e envia resposta
                        String resposta = "Servidor recebeu sua mensagem: " + mensagemCliente;
                        saida.writeObject(resposta);
                        saida.flush();
                    }

                } while (!mensagemCliente.equalsIgnoreCase("sair"));

                System.out.println("Cliente encerrou a conversa.");
                cliente.close();
            }

        } catch(Exception e){
            System.out.println("Erro: " + e.getMessage());
        }
    }
    
}

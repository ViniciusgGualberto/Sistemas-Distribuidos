/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package clientebancariotcp;

import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.net.Socket;
import java.util.Scanner;
import javax.swing.JOptionPane;

/**
 *
 * @author vinic
 */
public class ClienteBancarioTCP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Depois de abrir o socket e antes de ler a resposta
        String servidor = "localhost"; // ou IP do servidor
        int porta = 8000;

        try {
            Socket cliente = new Socket(servidor, porta);
            System.out.println("Conectado ao servidor!");

            ObjectOutputStream saida = new ObjectOutputStream(cliente.getOutputStream());
            ObjectInputStream entrada = new ObjectInputStream(cliente.getInputStream());

            Scanner teclado = new Scanner(System.in);
            String mensagem, resposta;

            do {
                System.out.print("Digite a operação (ou 'sair' para encerrar): ");
                mensagem = teclado.nextLine();

                // Envia mensagem para o servidor
                saida.writeObject(mensagem);
                saida.flush();

                if (!mensagem.equalsIgnoreCase("sair")) {
                    // Lê resposta do servidor
                    resposta = (String) entrada.readObject();
                    System.out.println("Servidor respondeu: " + resposta);
                }

            } while (!mensagem.equalsIgnoreCase("sair"));

            System.out.println("Conexão encerrada.");
            cliente.close();

        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

}

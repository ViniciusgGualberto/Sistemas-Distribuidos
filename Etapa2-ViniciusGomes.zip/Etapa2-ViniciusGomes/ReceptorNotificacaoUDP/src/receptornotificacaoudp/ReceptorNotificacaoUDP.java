/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package receptornotificacaoudp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;

/**
 *
 * @author vinic
 */
public class ReceptorNotificacaoUDP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        int porta = 8001; // Porta diferente do TCP
        try {
            DatagramSocket socket = new DatagramSocket(porta);
            System.out.println("Aguardando notificações na porta " + porta + "...");

            byte[] buffer = new byte[256];
            DatagramPacket pacote = new DatagramPacket(buffer, buffer.length);

            socket.receive(pacote); // Bloqueia até receber
            String mensagem = new String(pacote.getData(), 0, pacote.getLength());

            System.out.println("Notificação recebida: " + mensagem);

            socket.close();
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }
    
}

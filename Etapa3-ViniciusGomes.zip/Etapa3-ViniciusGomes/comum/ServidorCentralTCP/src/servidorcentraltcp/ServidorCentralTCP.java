package servidorcentraltcp;

import comum.ProtocoloMensagem;
import java.io.*;
import java.net.*;
import java.util.*;

public class ServidorCentralTCP {

    private static final int PORTA = 8000;

    // Simples "banco de dados" em memória: conta -> saldo
    private static final Map<String, Integer> saldos = new HashMap<>();

    // Config NomeServico
    private static final String NOME_HOST = "localhost";
    private static final int NOME_PORTA = 9000;

    public static void main(String[] args) {
        // Inicializa uma conta padrão
        saldos.putIfAbsent("1", 500); // conta 1 começa com 500

        // Registrar no NomeServico
        registrarNoNomeServico("servidorcentral", "localhost", String.valueOf(PORTA));

        System.out.println("[Servidor] ouvindo em " + PORTA);
        try ( ServerSocket servidor = new ServerSocket(PORTA)) {
            while (true) {
                Socket cliente = servidor.accept();
                new Thread(() -> atenderCliente(cliente)).start();
            }
        } catch (Exception e) {
            System.out.println("[Servidor] Erro: " + e.getMessage());
        }
    }

    private static void atenderCliente(Socket cliente) {
        String remoto = cliente.getInetAddress().getHostAddress();
        System.out.println("[Servidor] Cliente conectado: " + remoto);
        try ( BufferedReader in = new BufferedReader(new InputStreamReader(cliente.getInputStream()));  PrintWriter out = new PrintWriter(cliente.getOutputStream(), true)) {

            String linha;
            while ((linha = in.readLine()) != null) {
                Map<String, String> req = ProtocoloMensagem.desserializar(linha);
                String tipo = req.get("tipo");
                String topico = req.get("topico");
                String id = req.getOrDefault("id", "");

                if (!"comando".equalsIgnoreCase(tipo)) {
                    // ignora mensagens que não são comandos
                    continue;
                }

                Map<String, String> evento = ProtocoloMensagem.novaMensagem("evento", "resposta");
                evento.put("correlacao", id);
                evento.put("status", "ok");

                switch (topico) {
                    case "saldo": {
                        String conta = req.getOrDefault("conta", "1");
                        int saldo = saldos.getOrDefault(conta, 0);
                        evento.put("topico", "saldo_ok");
                        evento.put("conta", conta);
                        evento.put("saldo", String.valueOf(saldo));
                        out.println(ProtocoloMensagem.serializar(evento));
                        break;
                    }
                    case "deposito": {
                        String conta = req.getOrDefault("conta", "1");
                        int valor = Integer.parseInt(req.getOrDefault("valor", "0"));
                        int saldo = saldos.getOrDefault(conta, 0) + valor;
                        saldos.put(conta, saldo);

                        evento.put("topico", "deposito_ok");
                        evento.put("conta", conta);
                        evento.put("valor", String.valueOf(valor));
                        evento.put("saldo", String.valueOf(saldo));
                        out.println(ProtocoloMensagem.serializar(evento));

                        notificarUDP("deposito realizado; conta=" + conta + "; valor=" + valor + "; saldo=" + saldo);
                        break;
                    }
                    case "saque": {
                        String conta = req.getOrDefault("conta", "1");
                        int valor = Integer.parseInt(req.getOrDefault("valor", "0"));
                        int saldoAtual = saldos.getOrDefault(conta, 0);
                        if (valor <= saldoAtual) {
                            int novo = saldoAtual - valor;
                            saldos.put(conta, novo);

                            evento.put("topico", "saque_ok");
                            evento.put("conta", conta);
                            evento.put("valor", String.valueOf(valor));
                            evento.put("saldo", String.valueOf(novo));
                            out.println(ProtocoloMensagem.serializar(evento));

                            notificarUDP("saque realizado; conta=" + conta + "; valor=" + valor + "; saldo=" + novo);
                        } else {
                            evento.put("status", "erro");
                            evento.put("topico", "saque_negado");
                            evento.put("motivo", "saldo_insuficiente");
                            evento.put("conta", conta);
                            evento.put("saldo", String.valueOf(saldoAtual));
                            out.println(ProtocoloMensagem.serializar(evento));

                            notificarUDP("saque negado; conta=" + conta + "; valor=" + valor + "; saldo=" + saldoAtual);
                        }
                        break;
                    }
                    default: {
                        evento.put("status", "erro");
                        evento.put("topico", "comando_desconhecido");
                        evento.put("mensagem", "topico=" + topico);
                        out.println(ProtocoloMensagem.serializar(evento));
                    }
                }
            }

        } catch (Exception e) {
            System.out.println("[Servidor] Erro com cliente " + remoto + ": " + e.getMessage());
        }
    }

    // --- NomeServico helpers ---
    private static void registrarNoNomeServico(String servico, String host, String porta) {
        Map<String, String> cmd = ProtocoloMensagem.novaMensagem("comando", "registrar_servico");
        cmd.put("servico", servico);
        cmd.put("host", host);
        cmd.put("porta", porta);
        trocarMensagemComNomeServico(cmd);
    }

    private static List<String> listarInscritosUDP() {
        Map<String, String> cmd = ProtocoloMensagem.novaMensagem("comando", "listar_inscritos");
        Map<String, String> resp = trocarMensagemComNomeServico(cmd);
        String inscritos = resp.getOrDefault("inscritos", "");
        if (inscritos.isEmpty()) {
            return Collections.emptyList();
        }
        return Arrays.asList(inscritos.split(","));
    }

    private static Map<String, String> trocarMensagemComNomeServico(Map<String, String> cmd) {
        Map<String, String> resp = new HashMap<>();
        try ( Socket s = new Socket(NOME_HOST, NOME_PORTA);  BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));  PrintWriter out = new PrintWriter(s.getOutputStream(), true)) {
            out.println(ProtocoloMensagem.serializar(cmd));
            String linha = in.readLine();
            resp = ProtocoloMensagem.desserializar(linha);
        } catch (Exception e) {
            System.out.println("[Servidor] Falha ao falar com NomeServico: " + e.getMessage());
        }
        return resp;
    }

    // --- UDP Notify ---
    private static void notificarUDP(String mensagem) {
        List<String> destinos = listarInscritosUDP();
        for (String ep : destinos) {
            if (ep == null || ep.isBlank() || !ep.contains(":")) {
                continue;
            }
            String[] p = ep.split(":");
            String host = p[0];
            int porta = Integer.parseInt(p[1]);
            enviarUDP(host, porta, mensagem);
        }
    }

    private static void enviarUDP(String host, int porta, String mensagem) {
        try ( DatagramSocket ds = new DatagramSocket()) {
            byte[] dados = mensagem.getBytes();
            DatagramPacket pkt = new DatagramPacket(dados, dados.length, InetAddress.getByName(host), porta);
            ds.send(pkt);
            System.out.println("[Servidor] Notificação UDP enviada a " + host + ":" + porta + " -> " + mensagem);
        } catch (Exception e) {
            System.out.println("[Servidor] Erro enviando UDP: " + e.getMessage());
        }
    }
}

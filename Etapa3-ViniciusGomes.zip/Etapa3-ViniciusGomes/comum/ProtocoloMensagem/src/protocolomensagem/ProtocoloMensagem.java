/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package ProtocoloMensagem;

/**
 *
 * @author vinic
 */

import java.util.HashMap;
import java.util.Map;

public class ProtocoloMensagem {

    // Serializa um mapa para uma linha: chave=valor;chave2=valor2\n
    public static String serializar(Map<String, String> campos) {
        StringBuilder sb = new StringBuilder();
        boolean primeiro = true;
        for (Map.Entry<String, String> e : campos.entrySet()) {
            if (!primeiro) sb.append(";");
            sb.append(e.getKey()).append("=").append(e.getValue());
            primeiro = false;
        }
        return sb.toString();
    }

    // Desserializa a linha no formato chave=valor;... em um Map
    public static Map<String, String> desserializar(String linha) {
        Map<String, String> mapa = new HashMap<>();
        if (linha == null) return mapa;
        String[] partes = linha.trim().split(";");
        for (String p : partes) {
            int i = p.indexOf('=');
            if (i > 0 && i < p.length() - 1) {
                String k = p.substring(0, i).trim();
                String v = p.substring(i + 1).trim();
                mapa.put(k, v);
            }
        }
        return mapa;
    }

    // Helpers
    public static Map<String, String> novaMensagem(String tipo, String topico) {
        Map<String, String> m = new HashMap<>();
        m.put("tipo", tipo);        // comando | evento
        m.put("topico", topico);    // ex.: deposito, saque, saldo
        m.put("id", String.valueOf(System.nanoTime()));
        return m;
    }
}


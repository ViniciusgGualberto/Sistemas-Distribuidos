/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package protocolomensagem;

import java.io.Serializable;

/**
 *
 * @author vinic
 */
public class comum implements Serializable{
    private String operacao;
    private String dados;

    public ProtocoloMensagem(String operacao, String dados) {
        this.operacao = operacao;
        this.dados = dados;
    }

    public String getOperacao() {
        return operacao;
    }

    public void setOperacao(String operacao) {
        this.operacao = operacao;
    }

    public String getDados() {
        return dados;
    }

    public void setDados(String dados) {
        this.dados = dados;
    }

    @Override
    public String toString() {
        return "Operação: " + operacao + " | Dados: " + dados;
    }
}

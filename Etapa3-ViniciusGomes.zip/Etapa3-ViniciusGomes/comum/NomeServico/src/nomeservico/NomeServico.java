/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package nomeservico;

import comum.ProtocoloMensagem;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.*;
/**
 *
 * @author vinic
 */


public class NomeServico {

    private static final int PORTA = 9000;

    // servico -> lista de endpoints "host:porta"
    private static final Map<String, List<String>> registroServicos = new HashMap<>();
    // inscritos UDP -> conjunto de endpoints "host:porta"
    private static final Set<String> inscritosUDP = new HashSet<>();

    public static void main(String[] args) {
        System.out.println("[NomeServico] ouvindo em " + PORTA);
        try (ServerSocket server = new ServerSocket(PORTA)) {
            while (true) {
                Socket cli = server.accept();
                new Thread(() -> atender(cli)).start();
            }
        } catch (Exception e) {
            System.out.println("[NomeServico] Erro: " + e.getMessage());
        }
    }

    private static void atender(Socket cli) {
        String remoto = cli.getInetAddress().getHostAddress();
        try (BufferedReader in = new BufferedReader(new InputStreamReader(cli.getInputStream()));
             PrintWriter out = new PrintWriter(cli.getOutputStream(), true)) {
            String linha = in.readLine();
            Map<String, String> req = ProtocoloMensagem.desserializar(linha);
            String topico = req.get("topico");

            Map<String, String> resp = ProtocoloMensagem.novaMensagem("evento", "resposta");
            resp.put("correlacao", req.getOrDefault("id", ""));
            resp.put("status", "ok");

            switch (topico) {
                case "registrar_servico": {
                    String servico = req.get("servico");
                    String host = req.get("host");
                    String porta = req.get("porta");
                    if (servico != null && host != null && porta != null) {
                        registroServicos.computeIfAbsent(servico, k -> new ArrayList<>());
                        String ep = host + ":" + porta;
                        if (!registroServicos.get(servico).contains(ep)) {
                            registroServicos.get(servico).add(ep);
                        }
                        resp.put("topico", "registrar_ok");
                        resp.put("servico", servico);
                        resp.put("endpoint", ep);
                    } else {
                        resp.put("status", "erro");
                        resp.put("mensagem", "parametros faltando");
                    }
                    break;
                }
                case "consultar_servico": {
                    String servico = req.get("servico");
                    List<String> eps = registroServicos.getOrDefault(servico, Collections.emptyList());
                    resp.put("topico", "consulta_servico_ok");
                    resp.put("servico", servico == null ? "" : servico);
                    resp.put("endpoints", String.join(",", eps));
                    break;
                }
                case "inscrever_udp": {
                    String host = req.getOrDefault("host", remoto);
                    String porta = req.get("porta");
                    if (porta != null) {
                        inscritosUDP.add(host + ":" + porta);
                        resp.put("topico", "inscrever_udp_ok");
                        resp.put("endpoint", host + ":" + porta);
                    } else {
                        resp.put("status", "erro");
                        resp.put("mensagem", "porta obrigatoria");
                    }
                    break;
                }
                case "listar_inscritos": {
                    resp.put("topico", "listar_inscritos_ok");
                    resp.put("inscritos", String.join(",", inscritosUDP));
                    break;
                }
                default:
                    resp.put("status", "erro");
                    resp.put("mensagem", "topico desconhecido: " + topico);
            }

            out.println(ProtocoloMensagem.serializar(resp));

        } catch (Exception e) {
            System.out.println("[NomeServico] Erro ao atender " + remoto + ": " + e.getMessage());
        }
    }
}

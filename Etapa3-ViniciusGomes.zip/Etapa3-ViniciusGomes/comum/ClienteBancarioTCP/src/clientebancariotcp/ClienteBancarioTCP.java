package clientebancariotcp;

import comum.ProtocoloMensagem;
import java.io.*;
import java.net.Socket;
import java.util.Map;
import java.util.Scanner;

public class ClienteBancarioTCP {

    private static final String SERVIDOR = "localhost";
    private static final int PORTA = 8000;

    public static void main(String[] args) {
        try (Socket cliente = new Socket(SERVIDOR, PORTA);
             BufferedReader in = new BufferedReader(new InputStreamReader(cliente.getInputStream()));
             PrintWriter out = new PrintWriter(cliente.getOutputStream(), true);
             Scanner teclado = new Scanner(System.in)) {

            System.out.println("Conectado ao servidor bancário.");

            boolean rodando = true;
            while (rodando) {
                System.out.println("\n=== MENU ===");
                System.out.println("1) Ver saldo");
                System.out.println("2) Depositar");
                System.out.println("3) Sacar");
                System.out.println("0) Sair");
                System.out.print("Escolha: ");
                String op = teclado.nextLine().trim();

                Map<String, String> cmd;

                switch (op) {
                    case "1": {
                        cmd = ProtocoloMensagem.novaMensagem("comando", "saldo");
                        cmd.put("conta", "1");
                        out.println(ProtocoloMensagem.serializar(cmd));
                        exibirEvento(in);
                        break;
                    }
                    case "2": {
                        System.out.print("Valor do depósito: ");
                        String val = teclado.nextLine().trim();
                        cmd = ProtocoloMensagem.novaMensagem("comando", "deposito");
                        cmd.put("conta", "1");
                        cmd.put("valor", val);
                        out.println(ProtocoloMensagem.serializar(cmd));
                        exibirEvento(in);
                        break;
                    }
                    case "3": {
                        System.out.print("Valor do saque: ");
                        String val = teclado.nextLine().trim();
                        cmd = ProtocoloMensagem.novaMensagem("comando", "saque");
                        cmd.put("conta", "1");
                        cmd.put("valor", val);
                        out.println(ProtocoloMensagem.serializar(cmd));
                        exibirEvento(in);
                        break;
                    }
                    case "0":
                        rodando = false;
                        break;
                    default:
                        System.out.println("Opção inválida.");
                }
            }

            System.out.println("Encerrando cliente.");

        } catch (Exception e) {
            System.out.println("Erro no cliente: " + e.getMessage());
        }
    }

    private static void exibirEvento(BufferedReader in) throws IOException {
        String linha = in.readLine();
        Map<String, String> evt = ProtocoloMensagem.desserializar(linha);
        System.out.println("Evento: " + evt);
    }
}

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package remetentenotificacaoudp;

import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;

/**
 *
 * @author vinic
 */
public class RemetenteNotificacaoUDP {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        try {
            InetAddress destino = InetAddress.getByName("10.79.139.23"); // IP do receptor
            int porta = 8001;
            String mensagem = "Novo bloco minerado! Transação incluída.";

            byte[] dados = mensagem.getBytes();
            DatagramPacket pacote = new DatagramPacket(dados, dados.length, destino, porta);

            DatagramSocket socket = new DatagramSocket();
            socket.send(pacote);
            System.out.println("Notificação enviada via UDP: " + mensagem);

            socket.close();
        } catch (Exception e) {
            System.out.println("Erro: " + e.getMessage());
        }
    }

}

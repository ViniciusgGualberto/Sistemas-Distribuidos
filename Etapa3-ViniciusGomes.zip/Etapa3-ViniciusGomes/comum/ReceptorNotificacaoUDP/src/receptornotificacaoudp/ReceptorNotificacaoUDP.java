/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package receptornotificacaoudp;

import comum.ProtocoloMensagem;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.*;
import java.util.Map;

public class ReceptorNotificacaoUDP {

    private static final int PORTA_UDP = 8001;
    private static final String NOME_HOST = "localhost";
    private static final int NOME_PORTA = 9000;

    public static void main(String[] args) {
        // Inscreve no NomeServico
        inscreverUDP("localhost", String.valueOf(PORTA_UDP));

        System.out.println("[ReceptorUDP] aguardando notificações em " + PORTA_UDP);
        try (DatagramSocket socket = new DatagramSocket(PORTA_UDP)) {
            byte[] buffer = new byte[512];
            while (true) {
                DatagramPacket pacote = new DatagramPacket(buffer, buffer.length);
                socket.receive(pacote);
                String msg = new String(pacote.getData(), 0, pacote.getLength());
                System.out.println("[ReceptorUDP] " + msg);
            }
        } catch (Exception e) {
            System.out.println("[ReceptorUDP] Erro: " + e.getMessage());
        }
    }

    private static void inscreverUDP(String host, String porta) {
        Map<String, String> cmd = ProtocoloMensagem.novaMensagem("comando", "inscrever_udp");
        cmd.put("host", host);
        cmd.put("porta", porta);
        try (Socket s = new Socket(NOME_HOST, NOME_PORTA);
             BufferedReader in = new BufferedReader(new InputStreamReader(s.getInputStream()));
             PrintWriter out = new PrintWriter(s.getOutputStream(), true)) {
            out.println(ProtocoloMensagem.serializar(cmd));
            String linha = in.readLine();
            ProtocoloMensagem.desserializar(linha); // só para validar
            System.out.println("[ReceptorUDP] Inscrito no NomeServico: " + host + ":" + porta);
        } catch (Exception e) {
            System.out.println("[ReceptorUDP] Falha ao inscrever no NomeServico: " + e.getMessage());
        }
    }
}
